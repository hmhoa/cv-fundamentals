Hoang Ho - 1001654608
CSE 4310-001 Fundamentals of Computer Vision
Assignment 3 - Detecting Motion and Kalman Filters
Due April 6, 2022 by 11:59 PM

conda install scikit-video -c conda-forge
install ffmpeg

References: https://github.com/ajdillhoff/CSE4310/blob/main/frame_diff.ipynb
	    https://dillhoffaj.utasites.cloud/posts/tracking/

The following class demo was used as a starting point for the GUI: https://github.com/ajdillhoff/CSE4310/blob/main/qtdemo.py

To edit Hyperparameters/Inputs for the MotionDetector object:
	Lines 24-28 under gui.py are constants that can be edited as needed.